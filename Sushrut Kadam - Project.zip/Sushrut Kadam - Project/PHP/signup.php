<?php
  require 'includes\common.php';
  
  if(isset($_SESSION['id'])){
       header('location: products.php');
   }
   
  ?>

<html>
    <head>
        <title>Sign Up - Lifestyle Store</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        
        <link rel="stylesheet" href="NewCSS.css">
        
        <style>
            .row-style{
                margin-top: 100px;
                margin-bottom: 160px;
            }
        </style>
    </head>
    <body>
        
        <?php
          require 'includes\header.php';
        ?>
        
        <div class="container">
            <div class="row row-style">
                <div class="col-xs-4 col-xs-offset-4 column-style">
                    <h1>SIGN UP</h1>
                    <form method="post" action="signup_script.php">
                        <div class="form-group">
                            <input type="text" class="form-control" name="name" placeholder="Name" required="true" pattern="[A-Za-z-0-9]+\s[A-Za-z-'0-9]+">
                        </div> 
                        <div class="form-group">
                            <input type="email" class="form-control" name="email" placeholder="Email" required="true" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$">
                            <?php
                                if(isset($_GET["m1"])){
                                  echo $_GET['m1'];
                                }
                            ?>
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" name="password" placeholder="Password" required="true" pattern=".{6,}">
                            
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="contact" placeholder="Contact" maxlength="10" size="10" required="true">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="city" placeholder="City" required="true">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="address" placeholder="Address" required="true">
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary" name="create">Submit</button>
                        </div>
                    </form>
                </div>    
            </div>
        </div>
        
         <?php
         require "footer.php";
         ?>
    </body>
</html>

