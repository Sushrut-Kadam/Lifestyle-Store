<?php
 require "includes\common.php";
?>
<html>
    <head>
        <title>Login - Lifestyle Store</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        
        <link rel="stylesheet" href="NewCSS.css">
        
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        <style>
            .row-style{
                margin-top: 100px;
                margin-bottom: 215px;
            }
        </style>
    
    </head>
    <body>
        <?php
          require "includes\header.php";
        ?>
        
        <div class="container">
            <div class="row row-style">
                <div class="col-xs-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <h4>LOGIN</h4>
                        </div>
                        <div class="panel-body">
                            <p class="text-warning">Login to make a purchase</p>
                            <form method="post" action="login_submit.php">
                                <div class="form-group">
                                    <input type="text" class="form-control" name="email" placeholder="Email" required="true">
                                    <div><?php echo filter_input(INPUT_GET, 'email_error'); ?></div>
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control" name="password" placeholder="Password" required="true">
                                    <div><?php echo filter_input(INPUT_GET, 'password_error'); ?></div>
                                </div>
                                <div>
                                    <label><input type="checkbox" value="" checked>Remember me</label>
                                </div>
                                <div>
                                     <button type="submit" class="btn btn-primary">Login</button>
                                 </div>
                            </form>
                        </div>
                        <div class="panel-footer">Don't have an account? Register</div>
                    </div>
                </div>
            </div>
        </div>
        
        
        <?php
        require "footer.php";
        ?>
    
    </body>
</html>
