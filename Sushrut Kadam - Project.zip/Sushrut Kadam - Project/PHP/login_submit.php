<?php
   require "includes\common.php";
   
  $email = $_POST['email'];
  $email = mysqli_real_escape_string($con, $email);
  
  $password = $_POST['password'];
  $password = mysqli_escape_string($con, $password);
  $password = md5($password);
  
  $query_sel = "SELECT id, email FROM users WHERE email='".$email."' AND  password='".$password."'";
  $query_sel_result = mysqli_query($con, $query_sel) or die($mysqli_error($con));
  $num_rows = mysqli_num_rows($query_sel_result);
  
  if($num_rows == 0){
      echo 'Enter valid E-mail and Password';
      header('location: login.php');
  }else{
      $row = mysqli_fetch_array($query_sel_result);
      $_SESSION['email'] = $row['email'];
      $_SESSION['id'] = $row['id'];
      header('location: products.php');
  }
   
 ?>
