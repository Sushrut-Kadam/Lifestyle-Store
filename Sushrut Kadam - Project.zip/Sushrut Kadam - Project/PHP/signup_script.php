<?php
  require "includes\common.php";
   
   $name = filter_input(INPUT_POST, "name");
   $name = mysqli_real_escape_string($con, $name);
   
   $email = filter_input(INPUT_POST, "email");
   $email = mysqli_real_escape_string($con, $email);
   
   $password = filter_input(INPUT_POST, "password");
   $password = mysqli_real_escape_string($con, $password);
   $password = md5($password);
   
   $contact = filter_input(INPUT_POST, "contact");
   $contact = mysqli_real_escape_string($con, $contact);
   
   $city = filter_input(INPUT_POST, "city");
   $city = mysqli_real_escape_string($con, $city);
   
   $address = filter_input(INPUT_POST, "address");
   $address = mysqli_real_escape_string($con, $address);
   
   $regex_email = "/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/";
   $regex_num = "/^[789][0-9]{9}$/";
   
   $sel_query = "SELECT * FROM users WHERE email='$email'";
   $sel_query_result = mysqli_query($con, $sel_query) or die(mysqli_error($con));
   $rows_num = mysqli_num_rows($sel_query_result);
   
   if($rows_num!=0){
       $msg = "Email already exists";
       header('location: signup.php?m1=' .$msg);
   }
   elseif(!preg_match($regex_email, $email)){
      echo "Not a valid Email id";
   }elseif (!preg_match($regex_num, $contact)) {
      echo "Not a valid Phone number";
   }else{
      $reg_query = "INSERT INTO users(name, email, password, contact, city, address) VALUES('".$name."','".$email."','".$password."','".$contact."','".$city."', '".$address."')";
      $reg_submit = mysqli_query($con, $reg_query) or die(mysqli_error($con));
      $user_id = mysqli_insert_id($con);
      $_SESSION['email']= $email;
      $_SESSION['id']= $user_id;
      header('location: products.php');
   }
   
?>
